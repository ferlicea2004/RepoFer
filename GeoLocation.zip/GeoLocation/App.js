import React, {useEffect} from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import * as Location from 'expo-location';
export default function App() {

  const buscaLocation = async () =>{
    const {status}= await Location.requestForegroundPermissionsAsync()
    if(status!=='granted'){
      return Alert.alert('Permiso denegado')
    }
    const location=wait Location.getCurrentPositionAsync({})
    console.log(location)
  }
  useEffect(()=>{
    buscaLocation()
  })


  return (
    <View style={styles.container}>
      <Text>Open up App.js to start working on your app!</Text>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
